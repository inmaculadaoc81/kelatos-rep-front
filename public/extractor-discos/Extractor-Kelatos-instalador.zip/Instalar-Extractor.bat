@echo off
rem Lanza el instalador (no necesita permisos de administrador ni internet).
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Instalar.ps1"
