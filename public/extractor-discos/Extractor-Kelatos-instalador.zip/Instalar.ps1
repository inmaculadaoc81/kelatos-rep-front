﻿# Instalador del Extractor de discos de Kelatos (Windows, por usuario: NO pide permisos de administrador).
# Copia la aplicación a %LOCALAPPDATA%\Kelatos\ExtractorDiscos, crea accesos directos (escritorio y menú Inicio)
# y la registra en «Aplicaciones» para poder desinstalarla. No descarga nada: funciona sin internet.
param([switch]$Silencioso)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing

function Aviso($texto, $icono = 'Information') {
  if (-not $Silencioso) { [void][System.Windows.Forms.MessageBox]::Show($texto, 'Extractor de discos · Kelatos', 'OK', $icono) } else { Write-Host $texto }
}

try {
  $app = Join-Path $PSScriptRoot 'Extractor-Kelatos.html'
  if (-not (Test-Path $app)) { throw "No encuentro Extractor-Kelatos.html junto al instalador." }

  # Navegador: Edge (viene con Windows) o Chrome. Hace falta uno de los dos para elegir carpetas.
  $pf = $env:ProgramFiles; $pf86 = ${env:ProgramFiles(x86)}
  $navegadores = @(
    "$pf86\Microsoft\Edge\Application\msedge.exe", "$pf\Microsoft\Edge\Application\msedge.exe",
    "$pf\Google\Chrome\Application\chrome.exe", "$pf86\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
  )
  $navegador = $navegadores | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
  if (-not $navegador) { throw "No se ha encontrado Microsoft Edge ni Google Chrome. Instala uno de los dos y vuelve a ejecutar el instalador." }

  $carpeta = Join-Path $env:LOCALAPPDATA 'Kelatos\ExtractorDiscos'
  New-Item -ItemType Directory -Force -Path $carpeta | Out-Null
  Copy-Item $app (Join-Path $carpeta 'Extractor-Kelatos.html') -Force
  foreach ($f in 'Desinstalar.ps1', 'LEEME.txt') { $o = Join-Path $PSScriptRoot $f; if (Test-Path $o) { Copy-Item $o (Join-Path $carpeta $f) -Force } }

  # Icono propio (cuadrado azul con una «K»), generado aquí para no depender de ningún archivo externo.
  $ico = Join-Path $carpeta 'extractor.ico'
  try {
    $bmp = New-Object System.Drawing.Bitmap 64, 64
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'; $g.TextRenderingHint = 'AntiAlias'
    $ruta = New-Object System.Drawing.Drawing2D.GraphicsPath
    $r = 14
    $ruta.AddArc(0, 0, $r, $r, 180, 90); $ruta.AddArc(64 - $r, 0, $r, $r, 270, 90); $ruta.AddArc(64 - $r, 64 - $r, $r, $r, 0, 90); $ruta.AddArc(0, 64 - $r, $r, $r, 90, 90); $ruta.CloseFigure()
    $g.FillPath((New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(66, 133, 244))), $ruta)
    $fuente = New-Object System.Drawing.Font 'Segoe UI', 34, ([System.Drawing.FontStyle]::Bold), ([System.Drawing.GraphicsUnit]::Pixel)
    $sf = New-Object System.Drawing.StringFormat; $sf.Alignment = 'Center'; $sf.LineAlignment = 'Center'
    $g.DrawString('K', $fuente, [System.Drawing.Brushes]::White, (New-Object System.Drawing.RectangleF 0, 2, 64, 64), $sf)
    $g.Dispose()
    $icono = [System.Drawing.Icon]::FromHandle($bmp.GetHicon())
    $fs = [System.IO.File]::Create($ico); $icono.Save($fs); $fs.Close()
  } catch { $ico = $navegador }

  # Los accesos abren la aplicación en su propia ventana (sin barra de direcciones), con el navegador elegido.
  $url = ([System.Uri](Join-Path $carpeta 'Extractor-Kelatos.html')).AbsoluteUri
  $sh = New-Object -ComObject WScript.Shell
  $accesos = @(
    (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Extractor de discos Kelatos.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) 'Extractor de discos Kelatos.lnk')
  )
  foreach ($a in $accesos) {
    $l = $sh.CreateShortcut($a)
    $l.TargetPath = $navegador
    $l.Arguments = "--app=`"$url`" --window-size=1200,900"
    $l.WorkingDirectory = $carpeta
    $l.IconLocation = $ico
    $l.Description = 'Copia los datos de un disco de cliente con comprobación archivo por archivo'
    $l.Save()
  }

  # Registro en «Aplicaciones e instalaciones» (solo para este usuario) para poder desinstalar.
  $clave = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\KelatosExtractorDiscos'
  New-Item -Path $clave -Force | Out-Null
  $des = Join-Path $carpeta 'Desinstalar.ps1'
  Set-ItemProperty $clave DisplayName 'Extractor de discos Kelatos'
  Set-ItemProperty $clave Publisher 'Kelatos'
  Set-ItemProperty $clave DisplayIcon $ico
  Set-ItemProperty $clave InstallLocation $carpeta
  Set-ItemProperty $clave UninstallString "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$des`""
  Set-ItemProperty $clave NoModify 1 -Type DWord
  Set-ItemProperty $clave NoRepair 1 -Type DWord

  Aviso "Instalado correctamente.`n`nTienes un acceso directo «Extractor de discos Kelatos» en el escritorio y en el menú Inicio. Funciona sin internet y sin el dashboard."
  if (-not $Silencioso) { Start-Process $navegador -ArgumentList "--app=`"$url`"", '--window-size=1200,900' }
} catch {
  Aviso ("No se pudo instalar:`n`n" + $_.Exception.Message) 'Error'
  exit 1
}
