﻿# Instalador del Extractor de discos de Kelatos (Windows, por usuario: NO pide permisos de administrador).
# Copia la aplicación a %LOCALAPPDATA%\Kelatos\ExtractorDiscos, crea accesos directos (escritorio y menú Inicio)
# y la registra en «Aplicaciones» para poder desinstalarla. No descarga nada: funciona sin internet.
param([switch]$Silencioso)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing

function Aviso($texto, $icono = 'Information') {
  if (-not $Silencioso) { [void][System.Windows.Forms.MessageBox]::Show($texto, 'Extractor de discos · Kelatos', 'OK', $icono) } else { Write-Host $texto }
}

try {
  $app = Join-Path $PSScriptRoot 'Extractor-Kelatos.html'
  if (-not (Test-Path $app)) { throw "No encuentro Extractor-Kelatos.html junto al instalador." }

  # Navegador: Edge (viene con Windows) o Chrome. Hace falta uno de los dos para elegir carpetas.
  $pf = $env:ProgramFiles; $pf86 = ${env:ProgramFiles(x86)}
  $navegadores = @(
    "$pf86\Microsoft\Edge\Application\msedge.exe", "$pf\Microsoft\Edge\Application\msedge.exe",
    "$pf\Google\Chrome\Application\chrome.exe", "$pf86\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
  )
  $navegador = $navegadores | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
  if (-not $navegador) { throw "No se ha encontrado Microsoft Edge ni Google Chrome. Instala uno de los dos y vuelve a ejecutar el instalador." }

  $carpeta = Join-Path $env:LOCALAPPDATA 'Kelatos\ExtractorDiscos'
  New-Item -ItemType Directory -Force -Path $carpeta | Out-Null
  Copy-Item $app (Join-Path $carpeta 'Extractor-Kelatos.html') -Force
  foreach ($f in 'Desinstalar.ps1', 'LEEME.txt') { $o = Join-Path $PSScriptRoot $f; if (Test-Path $o) { Copy-Item $o (Join-Path $carpeta $f) -Force } }

  # Icono propio (disco duro con flecha de salida sobre fondo azul), generado aquí para no depender de ningún archivo externo.
  $ico = Join-Path $carpeta 'extractor-disco.ico'
  Remove-Item (Join-Path $carpeta 'extractor.ico') -Force -ErrorAction SilentlyContinue
  try {
    function RectRedondo($x, $y, $w, $h, $r) {
      $rp = New-Object System.Drawing.Drawing2D.GraphicsPath
      $rp.AddArc($x, $y, $r, $r, 180, 90); $rp.AddArc($x + $w - $r, $y, $r, $r, 270, 90); $rp.AddArc($x + $w - $r, $y + $h - $r, $r, $r, 0, 90); $rp.AddArc($x, $y + $h - $r, $r, $r, 90, 90); $rp.CloseFigure()
      return $rp
    }
    $azul = [System.Drawing.Color]::FromArgb(66, 133, 244)
    function DibujaIcono($t) {
      $bmp = New-Object System.Drawing.Bitmap $t, $t
      $g = [System.Drawing.Graphics]::FromImage($bmp)
      $g.SmoothingMode = 'AntiAlias'; $g.ScaleTransform($t / 64.0, $t / 64.0)
      $g.FillPath((New-Object System.Drawing.SolidBrush $azul), (RectRedondo 0 0 64 64 14))
      $lapiz = New-Object System.Drawing.Pen ([System.Drawing.Color]::White), 4.5
      $lapiz.StartCap = 'Round'; $lapiz.EndCap = 'Round'; $lapiz.LineJoin = 'Round'
      $g.DrawLine($lapiz, 32, 9, 32, 22)
      $g.DrawLines($lapiz, @((New-Object System.Drawing.PointF 25, 16), (New-Object System.Drawing.PointF 32, 23), (New-Object System.Drawing.PointF 39, 16)))
      $g.FillPath([System.Drawing.Brushes]::White, (RectRedondo 11 30 42 22 8))
      $g.FillRectangle((New-Object System.Drawing.SolidBrush $azul), 18, 39, 15, 4)
      $g.FillEllipse((New-Object System.Drawing.SolidBrush $azul), 40, 38.5, 6, 6)
      $g.Dispose()
      return $bmp
    }
    # .ico con imágenes PNG de 16, 32, 48 y 256 px (Windows las elige según el tamaño; así se conserva el color y la transparencia)
    $tamanos = 16, 32, 48, 256
    $pngs = foreach ($t in $tamanos) { $ms = New-Object System.IO.MemoryStream; (DibujaIcono $t).Save($ms, [System.Drawing.Imaging.ImageFormat]::Png); ,$ms.ToArray() }
    $fs = [System.IO.File]::Create($ico); $w = New-Object System.IO.BinaryWriter $fs
    $w.Write([uint16]0); $w.Write([uint16]1); $w.Write([uint16]$tamanos.Count)
    $offset = 6 + 16 * $tamanos.Count
    for ($i = 0; $i -lt $tamanos.Count; $i++) {
      $t = $tamanos[$i]; $dim = if ($t -ge 256) { 0 } else { $t }
      $w.Write([byte]$dim); $w.Write([byte]$dim); $w.Write([byte]0); $w.Write([byte]0)
      $w.Write([uint16]1); $w.Write([uint16]32); $w.Write([uint32]$pngs[$i].Length); $w.Write([uint32]$offset)
      $offset += $pngs[$i].Length
    }
    foreach ($d in $pngs) { $w.Write([byte[]]$d) }
    $w.Close(); $fs.Close()
  } catch { $ico = $navegador }

  # Los accesos abren la aplicación en su propia ventana (sin barra de direcciones), con el navegador elegido.
  $url = ([System.Uri](Join-Path $carpeta 'Extractor-Kelatos.html')).AbsoluteUri
  $sh = New-Object -ComObject WScript.Shell
  $accesos = @(
    (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Extractor de discos Kelatos.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) 'Extractor de discos Kelatos.lnk')
  )
  foreach ($a in $accesos) {
    $l = $sh.CreateShortcut($a)
    $l.TargetPath = $navegador
    $l.Arguments = "--app=`"$url`" --window-size=1200,900"
    $l.WorkingDirectory = $carpeta
    $l.IconLocation = $ico
    $l.Description = 'Copia los datos de un disco de cliente con comprobación archivo por archivo'
    $l.Save()
  }

  # Registro en «Aplicaciones e instalaciones» (solo para este usuario) para poder desinstalar.
  $clave = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\KelatosExtractorDiscos'
  New-Item -Path $clave -Force | Out-Null
  $des = Join-Path $carpeta 'Desinstalar.ps1'
  Set-ItemProperty $clave DisplayName 'Extractor de discos Kelatos'
  Set-ItemProperty $clave Publisher 'Kelatos'
  Set-ItemProperty $clave DisplayIcon $ico
  Set-ItemProperty $clave InstallLocation $carpeta
  Set-ItemProperty $clave UninstallString "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$des`""
  Set-ItemProperty $clave NoModify 1 -Type DWord
  Set-ItemProperty $clave NoRepair 1 -Type DWord

  Aviso "Instalado correctamente.`n`nTienes un acceso directo «Extractor de discos Kelatos» en el escritorio y en el menú Inicio. Funciona sin internet y sin el dashboard."
  if (-not $Silencioso) { Start-Process $navegador -ArgumentList "--app=`"$url`"", '--window-size=1200,900' }
} catch {
  Aviso ("No se pudo instalar:`n`n" + $_.Exception.Message) 'Error'
  exit 1
}
