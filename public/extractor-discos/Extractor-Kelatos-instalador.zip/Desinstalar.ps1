﻿# Desinstala el Extractor de discos de Kelatos (solo quita la aplicación y sus accesos; no toca ninguna copia hecha).
param([switch]$Silencioso)
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms
$carpeta = Join-Path $env:LOCALAPPDATA 'Kelatos\ExtractorDiscos'
foreach ($a in @(
    (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Extractor de discos Kelatos.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) 'Extractor de discos Kelatos.lnk'))) { Remove-Item $a -Force }
Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\KelatosExtractorDiscos' -Recurse -Force
# El script se está ejecutando desde esa carpeta: se borra con un pequeño retraso desde otro proceso.
Start-Process cmd.exe -WindowStyle Hidden -ArgumentList '/c', "ping 127.0.0.1 -n 3 >nul & rmdir /s /q `"$carpeta`""
if (-not $Silencioso) { [void][System.Windows.Forms.MessageBox]::Show('Extractor de discos desinstalado.', 'Extractor de discos · Kelatos', 'OK', 'Information') }
