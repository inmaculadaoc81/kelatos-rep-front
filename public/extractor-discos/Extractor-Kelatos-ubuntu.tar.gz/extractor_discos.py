#!/usr/bin/env python3
"""Kelatos · Extractor de discos de clientes (para Ubuntu).

Sirve para sacar copia de los datos de un disco que llega a reparaciones antes de
formatear. Solo usa la librería estándar de Python 3 (no hay que instalar nada).

    sudo python3 extractor_discos.py            # abre http://127.0.0.1:8765 en el navegador

Reglas de seguridad (no se pueden saltar desde la interfaz):
  * El disco del cliente SIEMPRE se monta en SOLO LECTURA (ro). Nunca se escribe en él.
  * El destino no puede estar dentro de un disco de cliente montado.
  * Cada fichero copiado lleva su SHA-256 y se verifica leyendo la copia de nuevo.
  * Un fichero ilegible (disco dañado) no detiene la copia: se anota en el informe.
"""
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

PUERTO = int(os.environ.get("EXTRACTOR_PUERTO", "8765"))
DESTINO_BASE = os.environ.get("EXTRACTOR_DESTINO", "/srv/extracciones")
MONTAJE_BASE = "/mnt/cliente"
# Modo demo (para ver la interfaz sin un disco real, también en Windows): EXTRACTOR_DEMO=<carpeta que hará de disco>
DEMO = os.environ.get("EXTRACTOR_DEMO")

CATEGORIAS = {
    "documentos": ("Documentos (Word, Excel, PDF, texto…)", "doc docx xls xlsx xlsm ppt pptx pdf odt ods odp txt csv rtf md".split()),
    "fotos": ("Fotos", "jpg jpeg png gif bmp tif tiff heic webp raw cr2 nef arw dng".split()),
    "videos": ("Vídeos", "mp4 mov avi mkv wmv mpg mpeg m4v 3gp".split()),
    "musica": ("Música", "mp3 wav flac m4a aac ogg wma".split()),
    "correo": ("Correo (Outlook, Thunderbird…)", "pst ost eml mbox msg".split()),
    "otros": ("Contabilidad / diseño / otros programas", "dwg dxf psd ai indd skp kdbx sqlite db accdb mdb zip rar 7z".split()),
}
# Carpetas de sistema que nunca interesan (y que hacen la copia eterna).
IGNORAR = {"windows", "program files", "program files (x86)", "programdata", "$recycle.bin", "system volume information",
           "recovery", "$windows.~bt", "appdata", "node_modules", ".cache", "proc", "sys", "dev", "lost+found", "perflogs"}

lock = threading.Lock()
ESTADO = {"montado": None, "analisis": None, "trabajo": None, "escaneo": None}


def ejecutar(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.returncode, (r.stdout + r.stderr).strip()


def discos():
    if DEMO:
        return [{"ruta": "/dev/demo1", "tam": 500 * 10**9, "fs": "ntfs", "etiqueta": "DISCO DE DEMOSTRACIÓN", "modelo": "carpeta de prueba", "montado_en": None, "sistema": False}]
    rc, out = ejecutar(["lsblk", "-J", "-b", "-o", "NAME,PATH,SIZE,FSTYPE,LABEL,MOUNTPOINT,TYPE,RM,MODEL,PKNAME"])
    if rc != 0:
        return []
    datos = json.loads(out)["blockdevices"]
    planos = []

    def rec(nodo, padre=None):
        planos.append({**nodo, "padre": padre})
        for h in nodo.get("children") or []:
            rec(h, nodo)

    for d in datos:
        rec(d)
    res = []
    for n in planos:
        if n["type"] != "part" or not n.get("fstype"):
            continue
        if n["fstype"] in ("swap", "crypto_LUKS", "LVM2_member"):
            continue
        # El disco del propio Ubuntu (sistema) se marca para no confundirse.
        es_sistema = n.get("mountpoint") in ("/", "/boot", "/boot/efi", "/home", "[SWAP]")
        res.append({
            "ruta": n["path"], "tam": int(n.get("size") or 0), "fs": n["fstype"], "etiqueta": n.get("label") or "",
            "modelo": (n["padre"] or {}).get("model") or "", "montado_en": n.get("mountpoint"), "sistema": es_sistema,
        })
    return res


def montar(ruta):
    if not re.fullmatch(r"/dev/[A-Za-z0-9_\-/]+", ruta):
        raise ValueError("Dispositivo no válido")
    if ESTADO["montado"]:
        raise ValueError("Ya hay un disco montado; desmóntalo primero")
    fs = next((d["fs"] for d in discos() if d["ruta"] == ruta), None)
    if not fs:
        raise ValueError("Ese dispositivo no está disponible")
    if DEMO:
        ESTADO["montado"] = {"ruta": ruta, "punto": os.path.abspath(DEMO), "fs": fs}
        ESTADO["analisis"] = None
        return ESTADO["montado"]
    destino = f"{MONTAJE_BASE}_{os.path.basename(ruta)}"
    os.makedirs(destino, exist_ok=True)
    if fs in ("ntfs", "ntfs3"):
        cmd = ["mount", "-t", "ntfs-3g", "-o", "ro,noatime", ruta, destino]
    elif fs.startswith("ext"):
        cmd = ["mount", "-o", "ro,noload,noatime", ruta, destino]  # noload: ni siquiera reproduce el journal
    elif fs in ("vfat", "exfat"):
        cmd = ["mount", "-o", "ro,noatime", ruta, destino]
    else:
        cmd = ["mount", "-o", "ro", ruta, destino]
    rc, out = ejecutar(cmd)
    if rc != 0 and fs in ("ntfs", "ntfs3"):
        rc, out = ejecutar(["mount", "-o", "ro,noatime", ruta, destino])  # ntfs-3g no instalado: usa el controlador del kernel
    if rc != 0:
        try:
            os.rmdir(destino)
        except OSError:
            pass
        raise ValueError(f"No se pudo montar en solo lectura: {out}. Si el disco no abre, puede estar dañado o con Windows en hibernación.")
    ESTADO["montado"] = {"ruta": ruta, "punto": destino, "fs": fs}
    ESTADO["analisis"] = None
    return ESTADO["montado"]


def desmontar():
    m = ESTADO["montado"]
    if not m:
        return
    if ESTADO["escaneo"] and ESTADO["escaneo"]["fase"] == "buscando":
        raise ValueError("Se está buscando archivos; espera a que termine")
    rc, out = (0, "") if DEMO else ejecutar(["umount", m["punto"]])
    if rc != 0:
        raise ValueError(f"No se pudo desmontar (¿hay una copia en curso?): {out}")
    try:
        os.rmdir(m["punto"])
    except OSError:
        pass
    ESTADO["montado"] = None
    ESTADO["analisis"] = None
    ESTADO["escaneo"] = None
    ESTADO["trabajo"] = None


def perfiles():
    """Carpetas de usuario del disco montado (Users/<nombre> en Windows, home/<nombre> en Linux)."""
    m = ESTADO["montado"]
    if not m:
        return []
    res = []
    for base in ("Users", "home"):
        p = os.path.join(m["punto"], base)
        if os.path.isdir(p):
            for n in sorted(os.listdir(p)):
                if n.lower() in ("public", "default", "default user", "all users", "defaultuser0", "lost+found"):
                    continue
                if os.path.isdir(os.path.join(p, n)):
                    res.append({"nombre": n, "ruta": os.path.join(p, n)})
    return res


def _ruta_dentro(ruta, base):
    ruta, base = os.path.realpath(ruta), os.path.realpath(base)
    return ruta == base or ruta.startswith(base + os.sep)


def analizar(raiz, categorias, todo):
    """Valida y lanza la búsqueda en segundo plano (el avance se consulta en /api/analisis)."""
    m = ESTADO["montado"]
    if not m or not _ruta_dentro(raiz, m["punto"]):
        raise ValueError("La carpeta elegida no está en el disco montado")
    if ESTADO["escaneo"] and ESTADO["escaneo"]["fase"] == "buscando":
        raise ValueError("Ya se está buscando; espera a que termine")
    if ESTADO["trabajo"] and ESTADO["trabajo"]["fase"] in ("copiando", "verificando"):
        raise ValueError("Hay una copia en curso")
    exts = {e: c for c in categorias for e in CATEGORIAS[c][1] if c in CATEGORIAS}
    esc = {"fase": "buscando", "n": 0, "bytes": 0, "actual": "", "resumen": {}}
    ESTADO["escaneo"] = esc
    ESTADO["analisis"] = None

    def trabajo():
        ficheros, resumen = [], {}
        try:
            for dirpath, dirs, files in os.walk(raiz, onerror=lambda e: None):
                dirs[:] = [d for d in dirs if d.lower() not in IGNORAR]
                esc["actual"] = os.path.relpath(dirpath, raiz) if dirpath != raiz else "."
                for f in files:
                    ext = f.rsplit(".", 1)[-1].lower() if "." in f else ""
                    cat = "todo" if todo else exts.get(ext)
                    if not cat:
                        continue
                    ruta = os.path.join(dirpath, f)
                    try:
                        tam = os.path.getsize(ruta)
                    except OSError:
                        tam = 0
                    ficheros.append((ruta, tam))
                    r = resumen.setdefault(cat, {"n": 0, "bytes": 0})
                    r["n"] += 1
                    r["bytes"] += tam
                    esc["n"] += 1
                    esc["bytes"] += tam
            esc["resumen"] = resumen
            ESTADO["analisis"] = {"raiz": raiz, "ficheros": ficheros, "resumen": resumen}
            esc["actual"] = ""
            esc["fase"] = "listo"
        except Exception as e:  # noqa: BLE001
            esc["fase"] = "error"
            esc["error"] = str(e)

    threading.Thread(target=trabajo, daemon=True).start()
    return {}


def sha256_copia(origen, destino):
    h = hashlib.sha256()
    with open(origen, "rb") as a, open(destino, "wb") as b:
        while True:
            bloque = a.read(1024 * 1024)
            if not bloque:
                break
            h.update(bloque)
            b.write(bloque)
    shutil.copystat(origen, destino, follow_symlinks=False)
    return h.hexdigest()


def sha256_fichero(ruta):
    h = hashlib.sha256()
    with open(ruta, "rb") as f:
        for bloque in iter(lambda: f.read(1024 * 1024), b""):
            h.update(bloque)
    return h.hexdigest()


def copiar(resguardo, nota):
    a, m = ESTADO["analisis"], ESTADO["montado"]
    if not a or not m:
        raise ValueError("Primero analiza el disco")
    if ESTADO["trabajo"] and ESTADO["trabajo"]["fase"] in ("copiando", "verificando"):
        raise ValueError("Ya hay una copia en curso")
    resguardo = re.sub(r"[^A-Za-z0-9_\-]", "", resguardo)
    if not resguardo:
        raise ValueError("Escribe el número de resguardo (solo letras, números, - y _)")
    carpeta = os.path.join(DESTINO_BASE, f"{resguardo}_{time.strftime('%Y%m%d_%H%M')}")
    if _ruta_dentro(carpeta, m["punto"]) or carpeta.startswith(MONTAJE_BASE):
        raise ValueError("El destino no puede estar en el disco del cliente")
    libre = shutil.disk_usage(DESTINO_BASE if os.path.isdir(DESTINO_BASE) else "/").free if os.path.isdir(DESTINO_BASE) or os.path.isdir("/") else 0
    necesario = sum(t for _, t in a["ficheros"])
    if libre and necesario * 1.02 > libre:
        raise ValueError(f"No hay espacio: hacen falta {necesario / 1e9:.1f} GB y quedan {libre / 1e9:.1f} GB en {DESTINO_BASE}")
    os.makedirs(carpeta, exist_ok=True)
    t = {"fase": "copiando", "hecho": 0, "total": len(a["ficheros"]), "bytes": 0, "bytes_total": necesario, "errores": [],
         "carpeta": carpeta, "inicio": time.time(), "resguardo": resguardo, "nota": nota, "verificados": 0, "fallos_verificacion": [], "actual": "", "verif_hecho": 0, "verif_total": 0}
    ESTADO["trabajo"] = t

    def trabajo():
        manifiesto = []
        raiz = a["raiz"]
        for ruta, tam in a["ficheros"]:
            rel = os.path.relpath(ruta, raiz)
            t["actual"] = rel
            dest = os.path.join(carpeta, "datos", rel)
            try:
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                h = sha256_copia(ruta, dest)
                manifiesto.append((rel, tam, h))
                t["bytes"] += tam
            except Exception as e:  # disco dañado, nombre raro, etc.: se anota y se sigue
                t["errores"].append(f"{rel}: {e}")
                try:
                    os.remove(dest)
                except OSError:
                    pass
            t["hecho"] += 1
        t["fase"] = "verificando"
        t["verif_total"] = len(manifiesto)
        for rel, tam, h in manifiesto:
            t["actual"] = rel
            t["verif_hecho"] += 1
            try:
                if sha256_fichero(os.path.join(carpeta, "datos", rel)) == h:
                    t["verificados"] += 1
                else:
                    t["fallos_verificacion"].append(rel)
            except Exception as e:
                t["fallos_verificacion"].append(f"{rel}: {e}")
        with open(os.path.join(carpeta, "MANIFIESTO_sha256.txt"), "w", encoding="utf-8") as f:
            for rel, tam, h in manifiesto:
                f.write(f"{h}  {rel}\n")
        dur = int(time.time() - t["inicio"])
        resumen = [
            f"Extracción de disco · resguardo {resguardo}",
            f"Fecha: {time.strftime('%Y-%m-%d %H:%M')}",
            f"Disco de origen: {m['ruta']} ({m['fs']}) montado en SOLO LECTURA",
            f"Carpeta analizada: {raiz}",
            f"Destino: {carpeta}",
            f"Ficheros copiados: {len(manifiesto)} de {t['total']} ({t['bytes'] / 1e9:.2f} GB) en {dur // 60} min {dur % 60} s",
            f"Verificados con SHA-256: {t['verificados']} · Fallos de verificación: {len(t['fallos_verificacion'])}",
            f"Ficheros que no se pudieron leer: {len(t['errores'])}",
        ]
        if nota:
            resumen.append(f"Nota: {nota}")
        if t["errores"]:
            resumen += ["", "NO COPIADOS (ilegibles):"] + t["errores"][:500]
        if t["fallos_verificacion"]:
            resumen += ["", "CON FALLO DE VERIFICACIÓN (repetir):"] + t["fallos_verificacion"][:500]
        with open(os.path.join(carpeta, "INFORME.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(resumen) + "\n")
        t["informe"] = "\n".join(resumen)
        t["fase"] = "terminado"

    threading.Thread(target=trabajo, daemon=True).start()
    return {"carpeta": carpeta}


def listar_carpetas(ruta):
    m = ESTADO["montado"]
    if not m or not _ruta_dentro(ruta, m["punto"]):
        raise ValueError("Ruta fuera del disco montado")
    return sorted(
        ({"nombre": n, "ruta": os.path.join(ruta, n)} for n in os.listdir(ruta) if os.path.isdir(os.path.join(ruta, n)) and n.lower() not in IGNORAR),
        key=lambda x: x["nombre"].lower(),
    )


PAGINA = r"""<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Extractor de discos · Kelatos</title>
<style>
:root{--verde:#1f9d6b;--verde2:#e6f6ef;--azul:#2563eb;--rojo:#c0392b;--rojo2:#fdecea;--amb:#b7791f;--amb2:#fff6e0;--txt:#1c2330;--gris:#5b6677;--borde:#dde1e8;--fondo:#f4f6f9}
*{box-sizing:border-box}
body{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;margin:0;color:var(--txt);background:var(--fondo);font-size:16px}
.wrap{max-width:900px;margin:0 auto;padding:20px 16px 48px}
header{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px}
header h1{font-size:22px;margin:0;flex:1}
.candado{background:var(--verde2);color:#146c4a;border:1px solid #b8e6d2;border-radius:999px;padding:5px 12px;font-size:13px;font-weight:600}
.pasos{display:flex;gap:0;margin:6px 0 18px;counter-reset:p}
.pasos .p{flex:1;text-align:center;position:relative;font-size:13px;color:var(--gris);cursor:default}
.pasos .p::before{content:attr(data-n);display:flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:50%;margin:0 auto 6px;background:#fff;border:2px solid var(--borde);font-weight:700;color:var(--gris);position:relative;z-index:1}
.pasos .p::after{content:"";position:absolute;top:16px;left:calc(50% + 20px);right:calc(-50% + 20px);height:3px;background:var(--borde)}
.pasos .p:last-child::after{display:none}
.pasos .p.hecho::before{content:"✓";background:var(--verde);border-color:var(--verde);color:#fff}
.pasos .p.hecho::after{background:var(--verde)}
.pasos .p.hecho{color:var(--txt);cursor:pointer}
.pasos .p.actual::before{border-color:var(--azul);color:var(--azul);box-shadow:0 0 0 4px #dbe7ff}
.pasos .p.actual{color:var(--txt);font-weight:700}
.tarjeta{background:#fff;border:1px solid var(--borde);border-radius:14px;padding:22px;box-shadow:0 1px 3px rgba(20,30,50,.05)}
.vista{display:none}.vista.on{display:block}
h2{font-size:20px;margin:0 0 4px}.ayuda{color:var(--gris);margin:0 0 16px;font-size:15px;line-height:1.45}
button{font:inherit;border:0;border-radius:10px;padding:11px 20px;cursor:pointer;font-weight:600;background:var(--azul);color:#fff}
button:hover{filter:brightness(1.07)}button:disabled{opacity:.45;cursor:not-allowed;filter:none}
button.grande{font-size:18px;padding:15px 28px}
button.verde{background:var(--verde)}button.sec{background:#e8ebf0;color:var(--txt)}button.rojo{background:var(--rojo)}
.fila{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
.disco{display:flex;align-items:center;gap:14px;border:2px solid var(--borde);border-radius:12px;padding:14px;margin-bottom:10px}
.disco .ico{font-size:34px}.disco .info{flex:1;min-width:0}.disco b{font-size:17px}.disco small{color:var(--gris);display:block;margin-top:2px}
.disco.sistema{opacity:.55;background:#f7f7f9}
.etq{display:inline-block;background:var(--amb2);color:var(--amb);border-radius:6px;padding:2px 8px;font-size:12px;font-weight:700;margin-left:6px}
.opciones{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px;margin:6px 0 14px}
.op{border:2px solid var(--borde);border-radius:12px;padding:12px;cursor:pointer;display:flex;gap:10px;align-items:center;user-select:none;background:#fff}
.op:hover{border-color:#b9c6e6}.op.sel{border-color:var(--azul);background:#eef3ff}
.op .e{font-size:26px}.op .t{font-weight:600;font-size:15px;line-height:1.2}.op .s{font-size:12px;color:var(--gris)}
.etiq{font-weight:700;margin:14px 0 6px;font-size:15px}
input[type=text]{width:100%;padding:12px;border:2px solid var(--borde);border-radius:10px;font:inherit}
input[type=text]:focus{outline:none;border-color:var(--azul)}
.barra{height:22px;background:#e6e9ef;border-radius:999px;overflow:hidden;position:relative}
.barra>i{display:block;height:100%;width:0;background:linear-gradient(90deg,#2fb583,#1f9d6b);border-radius:999px;transition:width .5s ease}
.barra.ind>i{width:40%!important;animation:ind 1.3s ease-in-out infinite}
@keyframes ind{0%{margin-left:-40%}100%{margin-left:100%}}
.barra.azul>i{background:linear-gradient(90deg,#4d86f7,#2563eb)}
.pct{font-size:44px;font-weight:800;line-height:1;margin:6px 0}
.chips{display:flex;gap:8px;margin:0 0 14px;flex-wrap:wrap}
.chip{padding:6px 14px;border-radius:999px;background:#eceff4;color:var(--gris);font-size:14px;font-weight:600}
.chip.on{background:#dbe7ff;color:var(--azul)}.chip.ok{background:var(--verde2);color:#146c4a}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin:14px 0}
.stat{background:#f6f8fb;border-radius:10px;padding:10px 12px}.stat b{display:block;font-size:20px}.stat span{font-size:12px;color:var(--gris)}
.actual{font-size:13px;color:var(--gris);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:6px}
table{width:100%;border-collapse:collapse;margin:10px 0;font-size:15px}
td,th{padding:8px 6px;text-align:left;border-bottom:1px solid #edf0f4}th{font-size:12px;color:var(--gris);text-transform:uppercase}
td.n{text-align:right;white-space:nowrap}.mini{height:8px;background:#e6e9ef;border-radius:99px;overflow:hidden;min-width:80px}.mini i{display:block;height:100%;background:var(--azul)}
.aviso{border-radius:10px;padding:12px 14px;margin:12px 0;font-size:15px;line-height:1.4}
.aviso.ok{background:var(--verde2);color:#146c4a}.aviso.mal{background:var(--rojo2);color:#8d2a20}.aviso.amb{background:var(--amb2);color:#7a5412}
.exito{text-align:center;padding:10px 0}.exito .gran{font-size:64px;line-height:1}
.ruta{background:#f0f2f5;border-radius:8px;padding:10px;font-family:ui-monospace,Consolas,monospace;font-size:13px;word-break:break-all;margin:8px 0}
details{margin:10px 0}summary{cursor:pointer;font-weight:600;color:var(--azul)}
pre{background:#f0f2f5;padding:12px;border-radius:8px;white-space:pre-wrap;font-size:12.5px;max-height:260px;overflow:auto}
.nav{display:flex;justify-content:space-between;gap:10px;margin-top:20px;flex-wrap:wrap}
.spin{display:inline-block;width:18px;height:18px;border:3px solid #cfd8ea;border-top-color:var(--azul);border-radius:50%;animation:g 0.8s linear infinite;vertical-align:-3px;margin-right:8px}
@keyframes g{to{transform:rotate(360deg)}}
</style>
<div class="wrap">
<header><h1>💾 Extractor de discos de clientes</h1><span class="candado">🔒 El disco del cliente solo se lee: nunca se modifica</span></header>

<div class="pasos" id="pasos">
 <div class="p" data-n="1" data-p="1">Disco</div>
 <div class="p" data-n="2" data-p="2">Qué copiar</div>
 <div class="p" data-n="3" data-p="3">Copiar</div>
 <div class="p" data-n="4" data-p="4">Terminar</div>
</div>

<!-- PASO 1 -->
<div class="tarjeta vista" id="v1">
 <h2>Paso 1 · Elige el disco del cliente</h2>
 <p class="ayuda">Conecta el disco del cliente por USB o SATA. Aparecerá aquí abajo. Pulsa <b>Abrir disco</b> en el que sea del cliente.</p>
 <div id="lista"><div><span class="spin"></span>Buscando discos…</div></div>
 <div id="m1"></div>
 <div class="nav"><button class="sec" onclick="cargarDiscos()">🔄 Buscar de nuevo</button><span></span></div>
</div>

<!-- PASO 2 -->
<div class="tarjeta vista" id="v2">
 <h2>Paso 2 · ¿Qué datos quiere el cliente?</h2>
 <p class="ayuda">Elige de quién son los datos y qué tipos de archivo hay que copiar. Después pulsa <b>Buscar archivos</b> para ver cuánto ocupa.</p>
 <div class="etiq">1. ¿De qué persona (usuario del equipo)?</div>
 <div class="opciones" id="perfiles"></div>
 <div class="etiq">2. ¿Qué tipo de archivos?</div>
 <div class="opciones" id="cats"></div>
 <div class="op" id="todoop" style="margin-bottom:14px" onclick="alternarTodo()"><span class="e">📦</span><span><span class="t">Copiar absolutamente todo</span><br><span class="s">Ignora los tipos de arriba (tarda más y ocupa más)</span></span></div>
 <div class="fila"><button class="grande" id="bAnalizar" onclick="analizar()">🔍 Buscar archivos</button></div>
 <div id="escaneo" style="display:none;margin-top:18px">
   <div id="escTitulo" class="etiq"><span class="spin"></span>Buscando archivos…</div>
   <div class="barra ind azul" id="escBarra"><i></i></div>
   <div class="stats"><div class="stat"><b id="escN">0</b><span>archivos encontrados</span></div><div class="stat"><b id="escB">0 GB</b><span>ocupan en total</span></div></div>
   <div class="actual" id="escAct"></div>
   <div id="escRes"></div>
 </div>
 <div id="m2"></div>
 <div class="nav"><button class="sec" onclick="ir(1)">← Atrás</button><button class="verde grande" id="bSig2" style="display:none" onclick="ir(3)">Continuar →</button></div>
</div>

<!-- PASO 3 -->
<div class="tarjeta vista" id="v3">
 <h2>Paso 3 · Copiar los archivos</h2>
 <div id="antes">
  <p class="ayuda" id="resumenCopia"></p>
  <div class="etiq">Número de resguardo <small style="color:var(--gris);font-weight:400">(obligatorio, para localizar la copia)</small></div>
  <input type="text" id="res" placeholder="Por ejemplo: 19640" autocomplete="off">
  <div class="etiq">Nota <small style="color:var(--gris);font-weight:400">(opcional)</small></div>
  <input type="text" id="nota" placeholder="Ej.: el cliente pidió solo las fotos" autocomplete="off">
  <div class="aviso amb" id="espacio" style="display:none"></div>
  <div id="m3"></div>
  <div class="nav"><button class="sec" onclick="ir(2)">← Atrás</button><button class="verde grande" id="bCopiar" onclick="copiar()">▶ Empezar la copia</button></div>
 </div>
 <div id="durante" style="display:none">
  <div class="chips"><span class="chip" id="c1">1 · Copiando</span><span class="chip" id="c2">2 · Comprobando que es idéntica</span><span class="chip" id="c3">3 · Listo</span></div>
  <div class="pct" id="pct">0%</div>
  <div class="barra" id="barraG"><i id="barra"></i></div>
  <div class="stats">
   <div class="stat"><b id="sCopiado">0 GB</b><span id="sCopiadoL">copiados de 0 GB</span></div>
   <div class="stat"><b id="sFich">0</b><span id="sFichL">archivos de 0</span></div>
   <div class="stat"><b id="sVel">—</b><span>velocidad</span></div>
   <div class="stat"><b id="sRest">—</b><span>tiempo restante</span></div>
  </div>
  <div class="actual" id="actual"></div>
  <div class="aviso amb" id="avErr" style="display:none"></div>
  <div class="aviso" style="background:#eef3ff;color:#1e3a8a">No cierres esta ventana ni desconectes el disco mientras copia.</div>
 </div>
 <div id="fin" style="display:none">
  <div class="exito"><div class="gran" id="finIco">✅</div><h2 id="finTit">¡Copia terminada!</h2><p class="ayuda" id="finTxt"></p></div>
  <div class="ruta" id="finRuta"></div>
  <div class="fila" style="justify-content:center"><button class="sec" onclick="copiarRuta()">📋 Copiar la ruta</button></div>
  <div id="finErr"></div>
  <details><summary>Ver el informe completo</summary><pre id="informe"></pre></details>
  <div class="nav"><span></span><button class="verde grande" onclick="ir(4)">Siguiente: desmontar el disco →</button></div>
 </div>
</div>

<!-- PASO 4 -->
<div class="tarjeta vista" id="v4">
 <h2>Paso 4 · Desmontar el disco</h2>
 <div id="desAntes">
  <p class="ayuda">Antes de desconectar el disco hay que «expulsarlo» con seguridad, para no dañarlo ni perder datos. Pulsa el botón y espera el mensaje verde.</p>
  <div class="fila"><button class="rojo grande" onclick="desmontar()">⏏ Desmontar el disco con seguridad</button></div>
  <div id="m4"></div>
 </div>
 <div id="desDespues" style="display:none">
  <div class="exito"><div class="gran">🎉</div><h2>Todo listo</h2><p class="ayuda">Ya puedes desconectar el disco del cliente. La copia está guardada y verificada.</p></div>
  <div class="ruta" id="desRuta"></div>
  <div class="nav"><span></span><button class="grande" onclick="location.reload()">➕ Empezar otra extracción</button></div>
 </div>
</div>
</div>

<script>
const $=id=>document.getElementById(id);
const api=async(u,o)=>{const r=await fetch(u,o);const j=await r.json();if(!j.ok)throw new Error(j.error||'Error');return j};
const post=(u,b)=>api(u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b||{})});
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const gb=b=>b>=1e9?(b/1e9).toFixed(1).replace('.',',')+' GB':b>=1e6?(b/1e6).toFixed(0)+' MB':(b/1e3).toFixed(0)+' KB';
const dur=s=>{s=Math.max(0,Math.round(s));if(s<60)return s+' s';const m=Math.floor(s/60);if(m<60)return m+' min '+(s%60)+' s';return Math.floor(m/60)+' h '+(m%60)+' min'};
const EMOJI={documentos:'📄',fotos:'🖼️',videos:'🎬',musica:'🎵',correo:'✉️',otros:'🧩'};
const S={paso:1,montado:null,perfil:null,cats:new Set(['documentos','fotos']),todo:false,analisis:null,destino:'',libre:0,carpeta:'',prev:null};

function ir(n){
 if(n===3&&!S.analisis)return;
 S.paso=n;
 document.querySelectorAll('.vista').forEach(v=>v.classList.toggle('on',v.id==='v'+n));
 document.querySelectorAll('#pasos .p').forEach(p=>{const k=+p.dataset.p;p.classList.toggle('actual',k===n);p.classList.toggle('hecho',k<n)});
 window.scrollTo({top:0,behavior:'smooth'});
 if(n===3)prepararPaso3();
 if(n===4){$('desRuta').textContent=S.carpeta||''}
}
document.querySelectorAll('#pasos .p').forEach(p=>p.onclick=()=>{const k=+p.dataset.p;if(k<S.paso&&!(S.paso>=3&&S.copiando))ir(k)});

async function cargarDiscos(){
 $('lista').innerHTML='<div><span class="spin"></span>Buscando discos…</div>';
 const j=await api('/api/discos');S.destino=j.destino;S.libre=j.libre;
 const l=$('lista');l.innerHTML='';
 if(!j.discos.length)l.innerHTML='<div class="aviso amb">No se detecta ningún disco. Conéctalo, espera unos segundos y pulsa «Buscar de nuevo».</div>';
 j.discos.forEach(d=>{
  const nombre=d.etiqueta||d.modelo||'Disco sin nombre';
  const e=document.createElement('div');e.className='disco'+(d.sistema?' sistema':'');
  e.innerHTML=`<div class="ico">${d.sistema?'🖥️':'💾'}</div><div class="info"><b>${esc(nombre)}</b>${d.sistema?'<span class="etq">DISCO DE ESTE EQUIPO · NO es del cliente</span>':''}<small>${gb(d.tam)} · ${esc(d.fs.toUpperCase())} · ${esc(d.ruta)}${d.modelo&&d.etiqueta?' · '+esc(d.modelo):''}</small></div>`;
  if(!d.sistema){const b=document.createElement('button');b.className='verde';b.textContent='Abrir disco';b.onclick=()=>montar(d.ruta,b);e.appendChild(b)}
  l.appendChild(e)});
 if(j.montado&&S.paso===1){S.montado=j.montado;await entrarPaso2()}
}
async function montar(r,b){
 b.disabled=true;$('m1').innerHTML='<div class="aviso" style="background:#eef3ff"><span class="spin"></span>Abriendo el disco en modo solo lectura…</div>';
 try{await post('/api/montar',{ruta:r});S.montado={ruta:r};$('m1').innerHTML='';await entrarPaso2()}
 catch(e){b.disabled=false;$('m1').innerHTML='<div class="aviso mal">'+esc(e.message)+'</div>'}
}
async function entrarPaso2(){
 const j=await api('/api/perfiles');const c=await api('/api/categorias');
 const caja=$('perfiles');caja.innerHTML='';
 const lista=[...j.perfiles.map(p=>({v:p.ruta,t:p.nombre,e:'👤',s:'Carpeta de usuario'})),{v:'__disco__',t:'Todo el disco',e:'🗂️',s:'Sin las carpetas del sistema'}];
 if(!S.perfil||!lista.some(x=>x.v===S.perfil))S.perfil=lista[0].v;
 lista.forEach(x=>{const d=document.createElement('div');d.className='op'+(x.v===S.perfil?' sel':'');d.innerHTML=`<span class="e">${x.e}</span><span><span class="t">${esc(x.t)}</span><br><span class="s">${x.s}</span></span>`;
  d.onclick=()=>{S.perfil=x.v;[...caja.children].forEach(h=>h.classList.remove('sel'));d.classList.add('sel');reiniciarAnalisis()};caja.appendChild(d)});
 const cc=$('cats');cc.innerHTML='';
 c.categorias.forEach(x=>{const d=document.createElement('div');const partes=x.nombre.split(' (');
  d.className='op'+(S.cats.has(x.id)?' sel':'');d.innerHTML=`<span class="e">${EMOJI[x.id]||'📁'}</span><span><span class="t">${esc(partes[0])}</span>${partes[1]?'<br><span class="s">'+esc(partes[1].replace(')',''))+'</span>':''}</span>`;
  d.onclick=()=>{S.cats.has(x.id)?S.cats.delete(x.id):S.cats.add(x.id);d.classList.toggle('sel');reiniciarAnalisis()};cc.appendChild(d)});
 ir(2)}
function alternarTodo(){S.todo=!S.todo;$('todoop').classList.toggle('sel',S.todo);$('cats').style.opacity=S.todo?.4:1;reiniciarAnalisis()}
function reiniciarAnalisis(){S.analisis=null;$('bSig2').style.display='none';$('escaneo').style.display='none';$('m2').innerHTML=''}

let timerEsc=null;
async function analizar(){
 if(!S.todo&&!S.cats.size){$('m2').innerHTML='<div class="aviso mal">Marca al menos un tipo de archivo (o «Copiar absolutamente todo»).</div>';return}
 $('m2').innerHTML='';$('bAnalizar').disabled=true;$('bSig2').style.display='none';
 $('escaneo').style.display='block';$('escRes').innerHTML='';$('escBarra').className='barra ind azul';$('escTitulo').innerHTML='<span class="spin"></span>Buscando archivos…';$('escN').textContent='0';$('escB').textContent='0 GB';$('escAct').textContent='';
 try{await post('/api/analizar',{raiz:S.perfil,categorias:[...S.cats],todo:S.todo})}
 catch(e){$('bAnalizar').disabled=false;$('escaneo').style.display='none';$('m2').innerHTML='<div class="aviso mal">'+esc(e.message)+'</div>';return}
 const vigilar=async()=>{
  try{const j=await api('/api/analisis');const a=j.analisis;if(!a)return;
   $('escN').textContent=a.n.toLocaleString('es-ES');$('escB').textContent=gb(a.bytes);$('escAct').textContent=a.actual?'Mirando: '+a.actual:'';
   if(a.fase==='buscando'){timerEsc=setTimeout(vigilar,700);return}
   $('bAnalizar').disabled=false;
   if(a.fase==='error'){$('escaneo').style.display='none';$('m2').innerHTML='<div class="aviso mal">'+esc(a.error||'Error al buscar')+'</div>';return}
   S.analisis=a;$('escBarra').className='barra azul';$('escBarra').firstElementChild.style.width='100%';$('escAct').textContent='';
   if(!a.n){$('escTitulo').innerHTML='🤷 No se ha encontrado nada con esos filtros';$('escRes').innerHTML='<div class="aviso amb">Prueba a marcar más tipos de archivo, a elegir «Todo el disco» o a copiar absolutamente todo.</div>';return}
   $('escTitulo').innerHTML='✅ Búsqueda terminada';
   const nombres={documentos:'Documentos',fotos:'Fotos',videos:'Vídeos',musica:'Música',correo:'Correo',otros:'Otros programas',todo:'Todo'};
   const total=Math.max(1,a.bytes);
   $('escRes').innerHTML='<table><tr><th>Tipo</th><th class="n">Archivos</th><th class="n">Tamaño</th><th></th></tr>'+Object.entries(a.resumen).map(([k,v])=>`<tr><td>${EMOJI[k]||'📁'} ${nombres[k]||k}</td><td class="n">${v.n.toLocaleString('es-ES')}</td><td class="n">${gb(v.bytes)}</td><td><div class="mini"><i style="width:${Math.round(100*v.bytes/total)}%"></i></div></td></tr>`).join('')+`<tr><td><b>Total</b></td><td class="n"><b>${a.n.toLocaleString('es-ES')}</b></td><td class="n"><b>${gb(a.bytes)}</b></td><td></td></tr></table>`;
   $('bSig2').style.display='inline-block';
  }catch(e){$('bAnalizar').disabled=false;$('m2').innerHTML='<div class="aviso mal">'+esc(e.message)+'</div>'}
 };
 vigilar();
}

function prepararPaso3(){
 const a=S.analisis;if(!a)return;
 $('antes').style.display='block';$('durante').style.display='none';$('fin').style.display='none';
 $('resumenCopia').innerHTML=`Se van a copiar <b>${a.n.toLocaleString('es-ES')} archivos (${gb(a.bytes)})</b>. Escribe el número de resguardo y pulsa el botón verde.`;
 const e=$('espacio');
 if(S.libre){const falta=a.bytes*1.02>S.libre;e.style.display='block';e.className='aviso '+(falta?'mal':'ok');
  e.innerHTML=falta?`⚠️ No hay espacio suficiente en <b>${esc(S.destino)}</b>: faltan ${gb(a.bytes*1.02-S.libre)}.`:`✔ Hay espacio de sobra. La copia se guardará en <b>${esc(S.destino)}</b> (libres: ${gb(S.libre)}).`;
  $('bCopiar').disabled=falta}
}
async function copiar(){
 $('m3').innerHTML='';
 if(!$('res').value.trim()){$('m3').innerHTML='<div class="aviso mal">Escribe el número de resguardo.</div>';$('res').focus();return}
 try{await post('/api/copiar',{resguardo:$('res').value,nota:$('nota').value});S.copiando=true;S.prev=null;
  $('antes').style.display='none';$('durante').style.display='block';seguir()}
 catch(e){$('m3').innerHTML='<div class="aviso mal">'+esc(e.message)+'</div>'}
}
async function seguir(){
 let j;try{j=await api('/api/progreso')}catch(e){setTimeout(seguir,2000);return}
 const t=j.trabajo;if(!t){return}
 const ver=t.fase==='verificando',fin=t.fase==='terminado';
 $('c1').className='chip '+(ver||fin?'ok':'on');$('c2').className='chip '+(fin?'ok':ver?'on':'');$('c3').className='chip '+(fin?'ok':'');
 let pct;
 if(ver){pct=t.verif_total?Math.round(100*t.verif_hecho/t.verif_total):100;$('barraG').classList.add('azul')}
 else{pct=t.bytes_total?Math.round(100*t.bytes/t.bytes_total):Math.round(100*t.hecho/Math.max(1,t.total));$('barraG').classList.remove('azul')}
 if(fin)pct=100;
 $('pct').textContent=pct+'%';$('barra').style.width=pct+'%';
 if(ver){$('sCopiado').textContent=(t.verif_hecho||0).toLocaleString('es-ES');$('sCopiadoL').textContent='comprobados de '+(t.verif_total||0).toLocaleString('es-ES')}
 else{$('sCopiado').textContent=gb(t.bytes);$('sCopiadoL').textContent='copiados de '+gb(t.bytes_total)}
 $('sFich').textContent=t.hecho.toLocaleString('es-ES');$('sFichL').textContent='archivos de '+t.total.toLocaleString('es-ES');
 const ahora=Date.now();
 if(!ver&&!fin){
  if(S.prev&&ahora-S.prev.t>0){const v=(t.bytes-S.prev.b)/((ahora-S.prev.t)/1000);S.vel=S.vel?S.vel*.6+v*.4:v}
  S.prev={t:ahora,b:t.bytes};
  if(S.vel>1){$('sVel').textContent=(S.vel/1e6).toFixed(0)+' MB/s';$('sRest').textContent=dur((t.bytes_total-t.bytes)/S.vel)}
 }else if(ver){$('sVel').textContent='—';$('sRest').textContent='casi listo'}
 $('actual').textContent=fin?'':(ver?'Comprobando: ':'Copiando: ')+(t.actual||'');
 if(t.errores.length){$('avErr').style.display='block';$('avErr').textContent='⚠️ '+t.errores.length+' archivo(s) no se han podido leer (disco dañado o bloqueado). La copia sigue; quedarán anotados en el informe.'}
 if(fin){S.copiando=false;S.carpeta=t.carpeta;mostrarFin(t);return}
 setTimeout(seguir,1000)
}
function mostrarFin(t){
 $('durante').style.display='none';$('fin').style.display='block';
 const malos=t.errores.length+t.fallos_verificacion.length;
 $('finIco').textContent=malos?'⚠️':'✅';
 $('finTit').textContent=malos?'Copia terminada, con avisos':'¡Copia terminada y verificada!';
 const tiempo=dur((Date.now()/1000)-t.inicio);
 $('finTxt').innerHTML=`<b>${t.verificados.toLocaleString('es-ES')}</b> archivos copiados (${gb(t.bytes)}) y comprobados uno a uno.`;
 $('finRuta').textContent=t.carpeta;
 $('finErr').innerHTML=malos?`<div class="aviso amb">${t.errores.length?t.errores.length+' archivo(s) ilegibles no copiados. ':''}${t.fallos_verificacion.length?t.fallos_verificacion.length+' con fallo de verificación (repetir la copia). ':''}Están listados en el informe.</div>`:'';
 $('informe').textContent=t.informe;
}
function copiarRuta(){navigator.clipboard&&navigator.clipboard.writeText(S.carpeta)}
async function desmontar(){
 $('m4').innerHTML='<div class="aviso" style="background:#eef3ff"><span class="spin"></span>Desmontando…</div>';
 try{await post('/api/desmontar');$('desAntes').style.display='none';$('desDespues').style.display='block'}
 catch(e){$('m4').innerHTML='<div class="aviso mal">'+esc(e.message)+'</div>'}
}
(async()=>{
 ir(1);
 try{
  const p=await api('/api/progreso');
  if(p.trabajo&&['copiando','verificando'].includes(p.trabajo.fase)){S.analisis={n:p.trabajo.total,bytes:p.trabajo.bytes_total};S.copiando=true;ir(3);$('antes').style.display='none';$('durante').style.display='block';seguir();return}
 }catch(e){}
 cargarDiscos();
})();
</script></html>
"""


class Manejador(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def responder(self, codigo, cuerpo, tipo="application/json"):
        datos = cuerpo.encode("utf-8") if isinstance(cuerpo, str) else cuerpo
        self.send_response(codigo)
        self.send_header("Content-Type", tipo + "; charset=utf-8")
        self.send_header("Content-Length", str(len(datos)))
        self.end_headers()
        self.wfile.write(datos)

    def json(self, obj, codigo=200):
        self.responder(codigo, json.dumps(obj, ensure_ascii=False))

    def do_GET(self):
        u = urlparse(self.path)
        try:
            if u.path == "/":
                return self.responder(200, PAGINA, "text/html")
            if u.path == "/api/discos":
                base = DESTINO_BASE if os.path.isdir(DESTINO_BASE) else "/"
                try:
                    libre = shutil.disk_usage(base).free
                except OSError:
                    libre = 0
                return self.json({"ok": True, "discos": discos(), "montado": ESTADO["montado"], "destino": DESTINO_BASE, "libre": libre})
            if u.path == "/api/analisis":
                return self.json({"ok": True, "analisis": ESTADO["escaneo"]})
            if u.path == "/api/perfiles":
                return self.json({"ok": True, "perfiles": perfiles()})
            if u.path == "/api/categorias":
                return self.json({"ok": True, "categorias": [{"id": k, "nombre": v[0]} for k, v in CATEGORIAS.items()]})
            if u.path == "/api/progreso":
                t = ESTADO["trabajo"]
                return self.json({"ok": True, "trabajo": t})
            if u.path == "/api/carpetas":
                return self.json({"ok": True, "carpetas": listar_carpetas(parse_qs(u.query).get("ruta", [""])[0])})
            self.json({"ok": False, "error": "No existe"}, 404)
        except Exception as e:
            self.json({"ok": False, "error": str(e)}, 400)

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        try:
            cuerpo = json.loads(self.rfile.read(n) or b"{}")
            with lock:
                if self.path == "/api/montar":
                    return self.json({"ok": True, "montado": montar(cuerpo.get("ruta", ""))})
                if self.path == "/api/desmontar":
                    desmontar()
                    return self.json({"ok": True})
                if self.path == "/api/analizar":
                    raiz = cuerpo.get("raiz", "")
                    if raiz == "__disco__":
                        raiz = ESTADO["montado"]["punto"] if ESTADO["montado"] else ""
                    return self.json({"ok": True, **analizar(raiz, cuerpo.get("categorias") or [], bool(cuerpo.get("todo")))})
                if self.path == "/api/copiar":
                    return self.json({"ok": True, **copiar(cuerpo.get("resguardo", ""), str(cuerpo.get("nota", ""))[:300])})
            self.json({"ok": False, "error": "No existe"}, 404)
        except Exception as e:
            self.json({"ok": False, "error": str(e)}, 400)


def main():
    if not DEMO and os.name != "posix":
        sys.exit("Esta herramienta es para Ubuntu/Linux (o usa EXTRACTOR_DEMO para ver la interfaz).")
    if not DEMO and os.geteuid() != 0:
        sys.exit("Ejecútala con permisos de administrador: sudo python3 extractor_discos.py")
    os.makedirs(DESTINO_BASE, exist_ok=True)
    if DEMO:
        print("MODO DEMO: no se monta nada, la carpeta", os.path.abspath(DEMO), "hace de disco.")
    srv = ThreadingHTTPServer(("127.0.0.1", PUERTO), Manejador)  # solo accesible desde el propio equipo
    print(f"Extractor listo: abre http://127.0.0.1:{PUERTO} en el navegador (Ctrl+C para salir). Copias en {DESTINO_BASE}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
