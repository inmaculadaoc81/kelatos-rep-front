#!/usr/bin/env bash
# Instalador del Extractor de discos de Kelatos para Ubuntu/Linux (por usuario, sin sudo, sin internet).
# Instala la aplicación (Extractor-Kelatos.html) y un lanzador en el menú de aplicaciones y en el escritorio.
# Si junto a este script está extractor_discos.py (versión Ubuntu con montaje en solo lectura), también la deja lista.
set -euo pipefail
AQUI="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.local/share/kelatos-extractor"
[ -f "$AQUI/Extractor-Kelatos.html" ] || { echo "Falta Extractor-Kelatos.html junto al instalador."; exit 1; }

NAV=""
for c in google-chrome google-chrome-stable chromium chromium-browser microsoft-edge microsoft-edge-stable brave-browser; do
  if command -v "$c" >/dev/null 2>&1; then NAV="$(command -v "$c")"; break; fi
done
[ -n "$NAV" ] || { echo "Hace falta Google Chrome, Chromium o Edge (Firefox no permite elegir carpetas). Instálalo y repite."; exit 1; }

mkdir -p "$DEST" "$HOME/.local/share/applications"
cp "$AQUI/Extractor-Kelatos.html" "$DEST/"
[ -f "$AQUI/LEEME.txt" ] && cp "$AQUI/LEEME.txt" "$DEST/"
[ -f "$AQUI/extractor_discos.py" ] && cp "$AQUI/extractor_discos.py" "$DEST/"

cat > "$DEST/extractor.svg" <<'SVG'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#4285f4"/><text x="32" y="46" font-family="Sans" font-weight="bold" font-size="40" text-anchor="middle" fill="#fff">K</text></svg>
SVG

LANZADOR="$HOME/.local/share/applications/kelatos-extractor.desktop"
cat > "$LANZADOR" <<EOF
[Desktop Entry]
Type=Application
Name=Extractor de discos Kelatos
Comment=Copia los datos de un disco de cliente con comprobación archivo por archivo
Exec="$NAV" --app="file://$DEST/Extractor-Kelatos.html" --window-size=1200,900
Icon=$DEST/extractor.svg
Terminal=false
Categories=Utility;
EOF
chmod +x "$LANZADOR"
ESC="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Escritorio")"
if [ -d "$ESC" ]; then cp "$LANZADOR" "$ESC/"; chmod +x "$ESC/kelatos-extractor.desktop"; gio set "$ESC/kelatos-extractor.desktop" metadata::trusted true 2>/dev/null || true; fi

echo "Instalado en $DEST"
echo "Abre «Extractor de discos Kelatos» desde el menú de aplicaciones o el escritorio."
[ -f "$DEST/extractor_discos.py" ] && echo "La versión Ubuntu con montaje en solo lectura queda en $DEST/extractor_discos.py (ejecutar con: sudo python3 extractor_discos.py)."
exit 0
