#!/bin/sh
# Abre el Extractor de discos de Kelatos en su propia ventana (Chrome, Edge, Brave o Chromium).
APP=/opt/kelatos-extractor/Extractor-Kelatos.html

buscar() {
  for c in google-chrome google-chrome-stable microsoft-edge microsoft-edge-stable brave-browser chromium chromium-browser; do
    if command -v "$c" >/dev/null 2>&1; then command -v "$c"; return 0; fi
  done
  return 1
}

NAV="$(buscar)"
if [ -z "$NAV" ]; then
  # Sin navegador compatible: se ofrece instalar Google Chrome (hace falta internet y la contraseña de administrador).
  if command -v zenity >/dev/null 2>&1; then
    zenity --question --title="Extractor de discos Kelatos" --width=420 \
      --text="Hace falta Google Chrome (Firefox no permite elegir carpetas).\n\n¿Instalarlo ahora? Pedirá la contraseña del equipo." || exit 1
  fi
  pkexec sh -c 'set -e; T=$(mktemp -d); (command -v wget >/dev/null && wget -q -O "$T/chrome.deb" https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb) || curl -fsSL -o "$T/chrome.deb" https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb; apt-get install -y "$T/chrome.deb"; rm -rf "$T"' \
    || { command -v zenity >/dev/null 2>&1 && zenity --error --text="No se pudo instalar Google Chrome. Comprueba la conexión a internet o instálalo a mano y vuelve a abrir el programa."; exit 1; }
  NAV="$(buscar)"
  [ -n "$NAV" ] || exit 1
fi

# El Chromium de snap no puede leer /opt ni discos externos: se copia la app a una carpeta visible del usuario.
case "$(readlink -f "$NAV")" in
  *snap*) mkdir -p "$HOME/Kelatos-Extractor"; cp "$APP" "$HOME/Kelatos-Extractor/"; APP="$HOME/Kelatos-Extractor/Extractor-Kelatos.html" ;;
esac
exec "$NAV" --app="file://$APP" --window-size=1200,900
